# How to run
- run PA3.java to start animation

# Interprets typed keys according to the following scheme
- Q : quit animation and close window
- R : resets the view to the initial rotation
- F : add food (for spider or butterfly) in tank
- B : add bird in tank
- > : add butterfly in tank